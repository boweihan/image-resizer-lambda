# image-resizer-lambda

Lambda code for resizing images on the fly.
